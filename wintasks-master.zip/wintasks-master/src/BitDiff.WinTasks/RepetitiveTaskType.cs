﻿namespace Bitdiff.WinTasks
{
    public enum RepetitiveTaskType
    {
        Interval,
        Daily,
        Weekly,
        Monthly
    }
}